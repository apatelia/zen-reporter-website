import { expect, test } from '@playwright/test';

test.describe('Tests in nested suite', () => {
  test(
    'has title',
    {
      tag: ['@title'],
    },
    async ({ page }) => {
      await test.step("Go to Playwright's website", async () => {
        await page.goto('https://playwright.dev/');
      });

      await test.step('Expect a title to contain "Playwright"', async () => {
        await expect(page).toHaveTitle(/Playwright/);
      });
    }
  );

  test(
    'get started link',
    {
      tag: ['@link', '@heading'],
    },
    async ({ page, browserName }, testInfo) => {
      await test.step("Go to Playwright's website", async () => {
        await page.goto('https://playwright.dev/');
      });

      await test.step('Click the get started link', async () => {
        await page.getByRole('link', { name: 'Get started' }).click();
      });

      await test.step('Expects page to have a heading with the name of Installation', async () => {
        await expect(page.getByRole('heading', { name: 'Installation' })).toBeVisible();

        console.log(`attaching screenshot for ${browserName}`);

        const screenshotPath = `screenshots/Installation-${browserName}.png`;
        await page.screenshot({ fullPage: false, path: screenshotPath });
        await testInfo.attach('Installation Screenshot', {
          path: screenshotPath,
          contentType: 'image/png',
        });

        console.log(`successfully attached screenshot for ${browserName}`);
      });
    }
  );
});
